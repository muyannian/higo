package com.alipay.bluewhale.core.task.error;

import com.alipay.bluewhale.core.callback.RunnableCallback;

/**
 * ��task�����쳣���ϱ��߳���ִ�е�runable
 * 
 * @author yannian
 * 
 */
public class TaskErrorRunable extends RunnableCallback {
	private TaskReportErrorAndDie report_error_and_die;

	public TaskErrorRunable(TaskReportErrorAndDie _report_error_and_die) {
		this.report_error_and_die = _report_error_and_die;
	}

	@Override
	public <T> Object execute(T... args) {
		Exception e = null;
		if (args != null && args.length > 0) {
			e = (Exception) args[0];
		}
		if (e != null) {
			report_error_and_die.report(e);
		}
		return null;
	}

}
