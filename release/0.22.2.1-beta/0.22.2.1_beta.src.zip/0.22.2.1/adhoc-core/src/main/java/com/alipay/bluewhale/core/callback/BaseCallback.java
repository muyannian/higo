package com.alipay.bluewhale.core.callback;

public class BaseCallback implements Callback {

	@Override
	public <T> Object execute(T... args) {
		// TODO Auto-generated method stub
		return null;
	}

}
