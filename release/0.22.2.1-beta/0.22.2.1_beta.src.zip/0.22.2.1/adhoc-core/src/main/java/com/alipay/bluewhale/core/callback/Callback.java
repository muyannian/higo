package com.alipay.bluewhale.core.callback;

/**
 * �ص��ӿ�
 * 
 * @author lixin 2012-3-12 ����2:22:54
 *
 */
public interface Callback {
	
	public<T> Object execute(T ...args);

}
