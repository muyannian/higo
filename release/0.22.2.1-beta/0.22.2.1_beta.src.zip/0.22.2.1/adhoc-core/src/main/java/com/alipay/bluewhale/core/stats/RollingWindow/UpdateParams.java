package com.alipay.bluewhale.core.stats.RollingWindow;

public class UpdateParams {
	public Object[] args;
	public Object curr;
}
