package com.alipay.bluewhale.core.task.acker;

public class AckObject {
	public Long val=null;
	public Object spout_task=null;
	public Boolean failed=false;
}
