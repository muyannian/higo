package com.alipay.bluewhale.core.task;

public interface StopCheck {
    public boolean isStop();
}
