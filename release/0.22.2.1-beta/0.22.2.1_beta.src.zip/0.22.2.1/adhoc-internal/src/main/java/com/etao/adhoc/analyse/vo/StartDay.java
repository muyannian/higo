package com.etao.adhoc.analyse.vo;

public class StartDay {
	private String startDay;

	public String getStartDay() {
		return startDay;
	}

	public void setStartDay(String startDay) {
		this.startDay = startDay;
	}

	@Override
	public String toString() {
		return "StartDay [startDay=" + startDay + "]";
	}

}
