package com.etao.adhoc.common.util;

import java.nio.charset.Charset;

public class CharSetUtil {
	public static final Charset UTF8 = Charset.forName("UTF-8");
}
