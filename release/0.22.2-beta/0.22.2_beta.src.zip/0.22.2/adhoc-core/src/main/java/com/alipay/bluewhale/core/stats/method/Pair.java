package com.alipay.bluewhale.core.stats.method;

public class Pair {
    public Long first;
    public Long second;

    public Pair() {
	first = 0l;
	second = 0l;
    }
}
