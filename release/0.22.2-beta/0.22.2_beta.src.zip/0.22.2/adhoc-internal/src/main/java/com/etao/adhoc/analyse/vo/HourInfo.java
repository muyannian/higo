package com.etao.adhoc.analyse.vo;

public class HourInfo {
	private String set;
	private String queryDate;
	private String queryHour;
	private int pv;
	public String getSet() {
		return set;
	}
	public void setSet(String set) {
		this.set = set;
	}
	public String getQueryDate() {
		return queryDate;
	}
	public void setQueryDate(String queryDate) {
		this.queryDate = queryDate;
	}
	public String getQueryHour() {
		return queryHour;
	}
	public void setQueryHour(String queryHour) {
		this.queryHour = queryHour;
	}
	public int getPv() {
		return pv;
	}
	public void setPv(int pv) {
		this.pv = pv;
	}
}
