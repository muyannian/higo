package com.alimama.quanjingmonitor.mdrillImport.parse;

public class DebugVersion {
	public static String version="8";
}
